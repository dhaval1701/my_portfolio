import { createContext, useContext, useState } from "react";

// themes/lightTheme.js
export const lightTheme = {
  background: "#ffffff",
  text: "#000000",
  // other styles...
};

// themes/darkTheme.js
export const darkTheme = {
  background: "#282c36",
  text: "#ffffff",
  // other styles...
};

const ThemeContext = createContext();

export const ThemeProvider = ({ children }) => {
  const [isDarkMode, setIsDarkMode] = useState(false);

  const toggleTheme = () => {
    setIsDarkMode((prevMode) => !prevMode);
  };

  const theme1 = isDarkMode ? darkTheme : lightTheme;

  return (
    <ThemeContext.Provider value={{ isDarkMode, toggleTheme, theme1 }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => {
  return useContext(ThemeContext);
};
