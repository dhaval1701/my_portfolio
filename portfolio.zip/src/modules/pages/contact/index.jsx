// components/Contact.js
import React from "react";
import { Card, Form, Input, Button, notification, Row, Col } from "antd";
import emailjs from "@emailjs/browser";
import image1 from "../../../assets/email_page.svg";

const Contact = () => {
  const onFinish = (values) => {
    // Replace these values with your Email.js template ID, user ID, and service ID
    const templateParams = {
      from_name: values.name,
      from_email: values.email,
      message: values.message,
    };

    emailjs
      .send(
        "your_service_id",
        "your_template_id",
        templateParams,
        "your_user_id"
      )
      .then(
        (response) => {
          console.log("Email sent successfully:", response);
          notification.success({
            message: "Success",
            description: "Your message has been sent successfully.",
          });
        },
        (error) => {
          console.error("Email failed to send:", error);
          notification.error({
            message: "Error",
            description: "Failed to send your message. Please try again later.",
          });
        }
      );
  };

  // {
  //   /* Map */
  // }
  // <Col xs={24} sm={12} md={12} lg={12}>
  //   {/* Replace the src attribute with the embed code from your map service */}
  //   <iframe
  //     title="locationMap"
  //     width="100%"
  //     height="600px"
  //     className="absolute inset-0"
  //     frameBorder={0}
  //     marginHeight={0}
  //     marginWidth={0}
  //     style={{ filter: "opacity(0.7)" }}
  //     src="https://www.google.com/maps/embed/v1/place?q=RATNAJYOT+COMPLEX+-2,+Nirnay+Nagar+Road,+Nirnay+Nagar+Sector+I,+Nirnay+Nagar,+Ahmedabad,+Gujarat,+India&key=AIzaSyBFw0Qbyq9zTFTd-tUY6dZWTgaQzuU17R8"
  //   ></iframe>
  // </Col>;

  return (
    <Row
      gutter={[16, 16]}
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        marginTop: "50px",
        padding: "40px",
      }}
    >
      {/* Contact Form */}
      <Col xs={24} sm={12} md={12} lg={12}>
        <Card title="Contact Us">
          <Form onFinish={onFinish} layout={"vertical"}>
            {/* Your form items go here */}
            <Form.Item
              name="name"
              label="Name"
              rules={[{ required: true, message: "Please enter your name" }]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="email"
              label="Email"
              rules={[
                { required: true, message: "Please enter your email" },
                { type: "email", message: "Please enter a valid email" },
              ]}
            >
              <Input />
            </Form.Item>
            <Form.Item
              name="message"
              label="Message"
              rules={[{ required: true, message: "Please enter your message" }]}
            >
              <Input.TextArea />
            </Form.Item>
            <Form.Item>
              <Button
                type="primary"
                htmlType="submit"
                style={{ color: "#001529" }}
              >
                Send
              </Button>
            </Form.Item>
          </Form>
        </Card>
      </Col>
    </Row>
  );
};

export default Contact;
