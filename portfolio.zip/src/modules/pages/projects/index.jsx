import React from "react";
import { Card, Row, Col } from "antd";
import { projects } from "../../../data/projects";

const Projects = () => {
  return (
    <div>
      <h1>Projects</h1>
      <Row gutter={[16, 16]}>
        {projects.map((project, index) => (
          <Col key={index} xs={24} sm={12} md={8} lg={6}>
            <Card
              hoverable
              style={{ width: "100%" }}
              cover={<img alt={project.title} src={project.image} />}
            >
              <Card.Meta title={project.title} description={project.subtitle} />
              <p>{project.description}</p>
              <a href={project.link} target="_blank" rel="noopener noreferrer">
                Learn more
              </a>
            </Card>
          </Col>
        ))}
      </Row>
    </div>
  );
};

export default Projects;
