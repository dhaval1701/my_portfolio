import styled from "styled-components";

export const Wrapper = styled.div`
  .menu-link {
    text-decoration: none;
  }
`;
